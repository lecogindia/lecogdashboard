(function() {
    " use strict ";

    const player = new Plyr('#player');
    const player1 = new Plyr('#player1');
    const player2 = new Plyr('#player2');

})();